#include "BSM_System.h"

void foobar() {
    printf("foobar\n");
}
