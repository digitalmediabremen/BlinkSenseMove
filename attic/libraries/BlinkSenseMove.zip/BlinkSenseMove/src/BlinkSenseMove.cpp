#include "BlinkSenseMove.h"

void init_BSM() {
}
